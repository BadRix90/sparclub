import { Component } from '@angular/core';

@Component({
  selector: 'app-sparer-selector',
  imports: [],
  templateUrl: './sparer-selector.component.html',
  styleUrl: './sparer-selector.component.scss'
})
export class SparerSelectorComponent {

}
