import { Component } from '@angular/core';

@Component({
  selector: 'app-sparer-card',
  imports: [],
  templateUrl: './sparer-card.component.html',
  styleUrl: './sparer-card.component.scss'
})
export class SparerCardComponent {

}
