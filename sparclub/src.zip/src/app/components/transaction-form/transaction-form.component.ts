import { Component } from '@angular/core';

@Component({
  selector: 'app-transaction-form',
  imports: [],
  templateUrl: './transaction-form.component.html',
  styleUrl: './transaction-form.component.scss'
})
export class TransactionFormComponent {

}
