import { Component } from '@angular/core';

@Component({
  selector: 'app-sparer-form',
  imports: [],
  templateUrl: './sparer-form.component.html',
  styleUrl: './sparer-form.component.scss'
})
export class SparerFormComponent {

}
