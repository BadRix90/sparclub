import { Component } from '@angular/core';

@Component({
  selector: 'app-overview-dashboard',
  imports: [],
  templateUrl: './overview-dashboard.component.html',
  styleUrl: './overview-dashboard.component.scss'
})
export class OverviewDashboardComponent {

}
