export interface Sparer {
}
