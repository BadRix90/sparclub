import { Component } from '@angular/core';

@Component({
  selector: 'app-main-dashboard',
  imports: [],
  templateUrl: './main-dashboard.component.html',
  styleUrl: './main-dashboard.component.scss'
})
export class MainDashboardComponent {

}
