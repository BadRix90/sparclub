import { Component } from '@angular/core';

@Component({
  selector: 'app-sparer-dashboard',
  imports: [],
  templateUrl: './sparer-dashboard.component.html',
  styleUrl: './sparer-dashboard.component.scss'
})
export class SparerDashboardComponent {

}
